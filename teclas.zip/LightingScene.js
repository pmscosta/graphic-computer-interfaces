var degToRad = Math.PI / 180.0;

var FLOOR_SIZE = 50;

var FPS = 60;

class LightingScene extends CGFscene 
{
	constructor()
	{
		super();

		
	};

	init(application) 
	{

		super.init(application);

		this.enableTextures(true);

		this.initCameras();

		this.initLights();

		this.option1=true; this.option2=false; this.speed=3;

		this.gl.clearColor(0.53, 0.81, 0.92, 1.0);
		this.gl.clearDepth(100.0);
		this.gl.enable(this.gl.DEPTH_TEST);
		this.gl.enable(this.gl.CULL_FACE);
		this.gl.depthFunc(this.gl.LEQUAL);

		this.drawAxis = true;
		this.axis = new CGFaxis(this);


		this.altimetry = [	
							[ 18.0 , 3.0 , 2.0, 6.0, 0, 0.0, 11.3, 18.3 ],
							[ 22.0 , 1.0 , 0.0, 4.0, 4, 0, 4.3, 32.3 ],
							[ 20.0 , 0.0 , 0.0, .4, 0.0, 0.0, 17.0, 18.0 ],
							[ 32.0 , 4.0 , 0.0, 0.0, 0.0, 0.0, 18.0, 25.0 ],
							[ 20.0 , 10.0 , 0.0, 0.0, 0, 2.4, 16.0, 43.0 ],
							[ 18.0 , 15.0 , 0.0, 0.0, 0, 2.4, 18.0, 32.0 ],
							[ 16.0 , 14.0 , 0.0, 0.0, 0.0, 14.0, 16.0, 22.0 ],
							[ 18.0 , 5.0 , 0.0, 0.0, 0.0, 14.0, 22.0, 15.0 ],
							[ 2.0 , 3.0 , 2.0, 1.0, 0.0, 2.4, 2.3, 18.0 ]];
		// Scene elements
		this.floor = new MyTerrain(this, 8, 1, 3/2, "../resources/images/rockyRoads.png", this.altimetry);
		this.vehicle = new MyVehicle(this);
		this.pickupZone = new Plane(this, 20); 
		this.crane = new MyCrane(this);
		
		this.vehicleAppearances = {black: new MyBlackVanTexture(this), red: new MyRedVanTexture(this), green: new MyGreenVanTexture(this)};
		this.curVehicleAppearance = null;


		// Materials
		this.materialDefault = new CGFappearance(this);


		this.noParking = new CGFappearance(this); 
		this.noParking.loadTexture("../resources/images/noParking.png");


		// Floor appearance
		this.floorAppearance = new CGFappearance(this);
		this.floorAppearance.loadTexture("../resources/images/floor.png");
		this.floorAppearance.setSpecular(0.1, 0.1, 0.1, 1);
		this.floorAppearance.setAmbient(1,1,1,1);
		this.floorAppearance.setDiffuse(0.8, 0.8, 0.8, 1);
		this.floorAppearance.setShininess(10);
		this.floorAppearance.setTextureWrap("REPEAT");
		
		this.materialC = new CGFappearance(this);
		this.materialC.setAmbient(0.2,0.05,0,1);
		this.materialC.setDiffuse(0.1,0.025,0,1);
		this.materialC.setSpecular(0.2,0.1,0,1);
		this.materialC.setShininess(500);
		
		
		this.t0 = Date.now();
		this.oldTime = this.t0;
		this.setUpdatePeriod(1000/FPS);
	};

	checkKeys(currTime)	{

		var keysPressed=false;

		var keys = new Map();

		//giving initial values
		keys.set('W', false);
		keys.set('S', false);
		keys.set('A', false);
		keys.set('D', false);

		if (this.gui.isKeyPressed("KeyW")){
			keysPressed=true;
			keys.set('W', true);
		}else
			keys.set('W', false);

		if (this.gui.isKeyPressed("KeyS")){
			keysPressed=true;
			keys.set('S', true);
		}else
			keys.set('S', false);

		if (this.gui.isKeyPressed("KeyA")){
			keysPressed=true;
			keys.set('A', true);
		}else
			keys.set('A', false);

		if (this.gui.isKeyPressed("KeyD")){
			keysPressed=true;
			keys.set('D', true);
		}else
			keys.set('D', false);
		
		if (keysPressed)
			this.vehicle.updateVelocity(currTime, keys);
	};

	doSomething()
	{ console.log("Doing something..."); };

	initCameras() 
	{
		this.camera = new CGFcamera(0.4, 0.1, 500, vec3.fromValues(20, 50,150), vec3.fromValues(0, 0, 0));
	};

	initLights() 
	{
	
		this.setGlobalAmbientLight(0.0, 0.0, 0.0, 1.0);

		// Positions for four lights
		this.lights[0].setPosition(-6.5, 1, -4.4, 1);
		this.lights[0].setVisible(true); // show marker on light position (different from enabled)
		
		this.lights[1].setPosition(-5, 5.0, 30.0, 1.0);
		this.lights[1].setVisible(true); // show marker on light position (different from enabled)

		this.lights[2].setPosition(15.5, 5.0, -7.0, 1.0);
		this.lights[2].setVisible(true);

		this.lights[3].setPosition(15,5,15,1);
		this.lights[3].setVisible(true);

		this.lights[4].setPosition(1,5,-8,1);
		this.lights[4].setVisible(true);

		this.lights[0].setAmbient(1, 1, 1, 1);
		this.lights[0].setDiffuse(1.0, 1.0, 1.0, 1.0);
		this.lights[0].setSpecular(1.0, 1.0, 0.0, 1.0);
		this.lights[0].setConstantAttenuation(0.0);
		this.lights[0].setLinearAttenuation(0.5);
		this.lights[0].setQuadraticAttenuation(0.0);
		this.lights[0].enable();

		this.lights[1].setAmbient(1, 1, 1, 1);
		this.lights[1].setDiffuse(1.0, 1.0, 1.0, 1.0);
		this.lights[1].setConstantAttenuation(0.0);
		this.lights[1].setLinearAttenuation(0.3);
		this.lights[1].setQuadraticAttenuation(0.0);
		this.lights[1].enable();

		this.lights[2].setAmbient(0, 0, 0, 1);
		this.lights[2].setDiffuse(1.0, 1.0, 1.0, 1.0);
		this.lights[2].setSpecular(1.0, 1.0, 1.0, 1.0);
		this.lights[2].setConstantAttenuation(0.0);
		this.lights[2].setLinearAttenuation(0.3);
		this.lights[2].setQuadraticAttenuation(0.0);
		this.lights[2].enable();

		this.lights[3].setAmbient(0, 0, 0, 1);
		this.lights[3].setDiffuse(1.0, 1.0, 1.0, 1.0);
		this.lights[3].setSpecular(1.0, 1.0, 1.0, 1.0);
		this.lights[3].setConstantAttenuation(0.0);
		this.lights[3].setLinearAttenuation(0.3);
		this.lights[3].setQuadraticAttenuation(0.0);
		this.lights[3].enable();

		this.lights[4].setAmbient(0, 0, 0, 1);
		this.lights[4].setDiffuse(1.0, 1.0, 1.0, 1.0);
		this.lights[4].setSpecular(1.0, 1.0, 1.0, 1.0);
		this.lights[4].setConstantAttenuation(0.0);
		this.lights[4].setLinearAttenuation(0.0);
		this.lights[4].setQuadraticAttenuation(0.01);
		this.lights[4].enable();
		
		this.lightEnable = new Array(4).fill(true);
		
		this.test = false;
		
	};

	update(timestamp){

		let currTime = timestamp - this.oldTime;

		let delta = timestamp-this.t0;
		this.checkKeys(currTime);
		this.vehicle.update(currTime, timestamp);
		
		if ( this.crane.inPickupRange(this.vehicle.position) ) {
					this.crane.seekVehicle(this.vehicle, delta);
		}
		else this.crane.vehicleSTime = inf;

		this.crane.update(delta);
		
		if ( this.curVehicleAppearance != null ) {
			this.vehicle.setTexture(this.vehicleAppearances[this.curVehicleAppearance]);
			this.curVehicleAppearance = null;
		}

		this.oldTime = timestamp; 
		
	};

	updateLights() 
	{

		for (var i = 0; i < this.lights.length ; i++) {
			
			this.lights[i].update();
		}
			
	}
	

	display() 
	{
		// ---- BEGIN Background, camera and axis setup

		// Clear image and depth buffer everytime we update the scene
		this.gl.viewport(0, 0, this.gl.canvas.width, this.gl.canvas.height);
		this.gl.clear(this.gl.COLOR_BUFFER_BIT | this.gl.DEPTH_BUFFER_BIT);

		// Initialize Model-View matrix as identity (no transformation)
		this.updateProjectionMatrix();
		this.loadIdentity();

		// Apply transformations corresponding to the camera position relative to the origin
		this.applyViewMatrix();

		// Update all lights used
		this.updateLights();


		// Draw axis
		if ( this.drawAxis ) this.axis.display();

		this.materialDefault.apply();

		// ---- END Background, camera and axis setup

		// ---- BEGIN Scene drawing section			


		//Vehicle
		this.pushMatrix();
			this.vehicle.display();
		this.popMatrix();	

		// Floor
		this.pushMatrix();
			this.translate(7.5, 0, 7.5);
			this.rotate(-90 * degToRad, 1, 0, 0);
			this.scale(FLOOR_SIZE, FLOOR_SIZE, 0.2);
			this.floor.display();
		this.popMatrix();

		//PickUp Zone
		this.pushMatrix();
			this.rotate(27*degToRad, 0, 1, 0);
			this.scale(4,1,6);
			this.translate(-0.4, 0.1, -0.6);
			this.rotate(-Math.PI / 2.0, 1, 0, 0);
			this.noParking.apply();
			this.pickupZone.display(); 
		this.popMatrix(); 
		// Crane
		this.pushMatrix();
			this.translate(3.5, .2, -3);
			this.rotate(90 * degToRad, 0, 1, 0);
			this.materialC.apply();
			this.crane.display();
		this.popMatrix();
			

		

		// ---- END Scene drawing section
	};
};
