 
class MyInterface extends CGFinterface {


	/**
	 * MyInterface
	 * @constructor
	 */
 	constructor () {
 		super();
 	}
	
	/**
	 * init
	 * @param {CGFapplication} application
	 */
	init(application) {
		this.dummyVar = false;
		
		// call CGFinterface init
		super.init(application);

		// init GUI. For more information on the methods, check:
		//  http://workshop.chromeexperiments.com/examples/gui

		this.gui = new dat.GUI();

		// add a button:
		// the first parameter is the object that is being controlled (in this case the scene)
		// the identifier 'doSomething' must be a function declared as part of that object (i.e. a member of the scene class)
		// e.g. LightingScene.prototype.doSomething = function () { console.log("Doing something..."); }; 

		// add a group of controls (and open/expand by defult)

		var group=this.gui.addFolder("Options");
		//group.open();

		// add two check boxes to the group. The identifiers must be members variables of the scene initialized in scene.init as boolean

		group.add(this.scene, 'drawAxis').name('draw axis');

		group.add(this.scene, 'curVehicleAppearance', Object.keys(this.scene.vehicleAppearances))
		.setValue('green');

		// add a slider
		// must be a numeric variable of the scene, initialized in scene.init e.g.
		// this.speed=3;
		// min and max values can be specified as parameters

		group.add(this.scene, 'speed', 0, 8).onChange((val) => {this.scene.vehicle.setMaxVelocity(val)}).setValue(3);
		
		group = this.gui.addFolder("Lights");
		group.open();
		for ( let i = 0; i < 5; ++i ) {
			var check = group.add(this, 'dummyVar').onChange((val) => {
				if ( val )	this.scene.lights[i].enable();
				else			this.scene.lights[i].disable();
				}).name(i).setValue(true);
		}
		
		group.close();


		this.initKeys();

		return true;
	};

	initKeys() {
		this.scene.gui=this;
		this.processKeyboard=function(){};
		this.activeKeys={};
	};

	processKeyDown(event) {
		this.activeKeys[event.code]=true;
	};

	processKeyUp(event) {
		this.activeKeys[event.code]=false;
	};

	isKeyPressed(keyCode) {
		return this.activeKeys[keyCode] || false;
	};

	
};

